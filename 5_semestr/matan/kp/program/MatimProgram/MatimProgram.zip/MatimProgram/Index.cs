﻿namespace MatimProgram
{
    public record Index
    {
        public int Start { get; init; }

        public int I { get; init; }

    }
}